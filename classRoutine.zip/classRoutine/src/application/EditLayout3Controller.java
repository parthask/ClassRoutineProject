package application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

public class EditLayout3Controller  {

	private static MainLayout2Controller obj2 = new MainLayout2Controller();
	private static ClassInfoLayout5Controller obj5 = new ClassInfoLayout5Controller();
	public static  String [] str2 = new String [4];

	@FXML
	private ComboBox<String> sbox;

	@FXML
	private ComboBox<String> bbox;

	@FXML
	private ComboBox<String> dbox;

	 @FXML
	    private TextField noOfClass;
//	private static String classInTotal;
//
	public TextField getNoOfClass() {
		return noOfClass;
	}
	public void setNoOfClass(TextField noOfClass) {
		this.noOfClass = noOfClass;
	}
//
//
//	public static String getClassInTotal() {
//		return classInTotal;
//	}
//
//
//	public static void setClassInTotal(String classInTotal) {
//		EditLayout3Controller.classInTotal = classInTotal;
//	}


	@FXML
	private Button go;

	@FXML
	private  void initialize(){
		sbox.setValue("CHOICE SEMESTER");
		bbox.setValue("CHOICE BATCH");
		dbox.setValue("CHOICE DAY NAME");

		sbox.setItems(ChoiceBoxData.semester);
		bbox.setItems(ChoiceBoxData.batch);
		dbox.setItems(ChoiceBoxData.dayNames);
		
	}


	@FXML
	private void infoButtoncontrol(ActionEvent event) throws Exception {
		str2[0]= sbox.getValue();
		str2[1]= bbox.getValue();
		str2[2]= dbox.getValue();
		str2[3]= noOfClass.getText();
		
		obj5.setN(str2[3]);		
		ClassInfoLayout5Controller.x= (Integer.parseInt(obj5.getN()));
		
		if(str2[0] == "CHOICE SEMESTER" || str2[1] == "CHOICE BATCH" ||  str2[2] == "CHOICE DAY NAME"){
			obj2.getAlart("SORRY...\nYOU HAVE TO SELECT ALL THREE OPTIONS!!!", "Be Alert!!!");
		}else if(!obj2.getFlag()){
			ClassInfoLayout5Controller.stage2.close();
			obj5.openNewLayout("/application/ClassInfoLayout5.fxml + CLASS SCHEDUELS...");
		}
	}

}
