package application;

import java.time.LocalDateTime;

public class GetNotifyTime {

	
	private String getCurrentTime(){
		
		String time = LocalDateTime.now().toLocalTime().toString();
		String timeArr []= time.split(":");
		String currentTime = timeArr[0]+":" +timeArr[1];
		return currentTime;
		
	}
}
