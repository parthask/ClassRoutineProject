package application;

import java.sql.SQLException;
import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class ShowLayout4Controller {
	private final ClassInfoLayout5Controller obj2 = new ClassInfoLayout5Controller();

	private static GetInfo6Controller obj6 = new GetInfo6Controller();
	//private static EditLayout3Controller obj5 = new EditLayout3Controller ();
	private  MysqlModel sqlmodelObj2 = new  MysqlModel();
	
	//The new 2nd layout instance to open it.	
		public static Stage stage2 = new Stage();

	@FXML
	private Label sem;

	@FXML
	private Label bat;

	@FXML
	private Label day;

	@FXML
	private Label cls;
	
	@FXML
    private Label title;

	@FXML
	private Label first;

	@FXML
	private Label second;

	@FXML
	private Label third;

	@FXML
	private Label fourth;

	@FXML
	private Label fifth;

	@FXML
	private Button goToMain;

	@FXML
	private Button exit;

	@FXML
	private AnchorPane showlayout;

	//private Label [] labelNames= {first, second, third, fourth, fifth};

	//info of the previous layout is stored in str2 to show it
	private static String str2 []= obj6.getStr();


	private static boolean flag;
	
	@FXML
	private void initialize(){

		sem.setText(str2[0]);
		bat.setText(str2[1]);
		day.setText(str2[2]);
		title.setText("*** "+str2[2]+"'s scheduled classes ***");

		
		try {
			sqlmodelObj2.getClassInfoFromDB(str2[0],str2[1], str2[2]);
			//System.out.println("have you called???");
		} catch (SQLException e) {
			System.out.println("problem in calling sql!!!");
			e.printStackTrace();
		}

		ArrayList<String> str3= sqlmodelObj2.getArr3(); // result set is here
		int totalClassNo = str3.size();
		// ArrayList<String> str4= sqlmodelObj2.getArr2();  // column name is here 
		int len= str3.size();
		for(;len<=5;len++){
			str3.add("No More Classes!");
		}
		cls.setText(Integer.toString(totalClassNo));
		first.setText(str3.get(0));
		second.setText(str3.get(1));
		third.setText(str3.get(2));
		fourth.setText(str3.get(3));
		fifth.setText(str3.get(4));
		
		str3.clear();
	
		}

	public void getConfirm(String infoMessage, String titleBar)
	{
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle(titleBar);
		alert.setHeaderText(null);
		alert.setContentText(infoMessage);
		alert.showAndWait();
		if(!alert.getResult().getButtonData().isCancelButton())
			System.exit(1);
	}


	@FXML
	private void goToMainOnAction(ActionEvent event) {		
		obj2.openNewLayout("/application/Layout2.fxml + *** ROUTINE MANAGEMENT *** ");
	}

	@FXML
	private void exitOnAction(ActionEvent event) {
		getConfirm("YOU ARE ABOUT TO EXITING THE APPLICATION!!! ", "Be Alert!!!");
     
	}
	
	
}
