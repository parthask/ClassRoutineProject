package application;

import java.sql.Connection;
import java.sql.DriverManager;

public class SqliteConnection {

	public static Connection connect() {
		try {
			String url   ="jdbc:mysql://localhost/routinedb";
			Connection conn = DriverManager.getConnection(url, "root", "");
			return conn;
		} catch (Exception e) {
			System.out.println("connection problem!!!");
			return null;
		}
	}


}
