package application;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class ChoiceBoxData {
	
	public static final ObservableList<String> batch=FXCollections.observableArrayList("CHOICE BATCH",
			"32nd", "33rd","34th", "35th", "36th", "37th", "38th", "39th", "40th",
			"41st","42nd","43rd","44th" );

	public static final ObservableList<String> semester =FXCollections.observableArrayList("CHOICE SEMESTER",
			"1st", "2nd","3rd", "4th", "5th", "6th", "7th", "8th", "9th",
			"10th","11th","12th" );

	public static final ObservableList<String> dayNames =FXCollections.observableArrayList("CHOICE DAY NAME",
			"SATURDAY", "SUNDAY", "MONDAY", "TUESDAY", "WEDNESDAY",
			"THURSDAY", "FRIDAY"); 

}
