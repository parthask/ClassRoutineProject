package application;


/*
 * 
 * this class has not been used by the author!!!
 */
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;


public class TwoButtonOnClickMethodsClass {
	
	//the instance of the 1st stage or layout to close it when the 2nd layout will start.
		public final Stage stage1 = MainLayout2.primaryStage;

	public void goToMainOnAction(AnchorPane showlayout) {
		
		stage1.show();
		//openNewLayout("/application/Layout2.fxml + *** ROUTINE MANAGEMENT *** ");
	}


	public void exitOnAction(ActionEvent event) {


	}

	//The every 2nd layout will begin from here with a title from the argument.
		public  void openNewLayout(String str1)  {
			String st [] = str1.split("\\+");
			try {		
				FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(st[0]));
				Parent root1 = (Parent) fxmlLoader.load();
				Stage stage2 = new Stage();
				stage2.setScene(new Scene(root1)); 
				//stage2.getIcons().add(new Image("gameIcon.PNG"));
				stage2.setResizable(false);
				stage2.setTitle(st[1]);
				stage2.show();
			} catch(Exception e) {
				e.printStackTrace();
			}

		}
}
