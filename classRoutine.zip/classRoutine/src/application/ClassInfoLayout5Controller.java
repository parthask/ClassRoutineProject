package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class ClassInfoLayout5Controller {
	private MysqlModel sqmodelObj1 = new  MysqlModel();
	private static MainLayout2Controller obj2 = new MainLayout2Controller();
	public static String timedata [] = new String [4];

	@FXML
	private TextField time;

	@FXML
	private TextField cCode;

	@FXML
	private TextField roomNo;

	@FXML
	private TextField nameOfTeacher;

	@FXML
	private Button ok;

	//static boolean flag ;
	private String n;
	public static int x;

	private static String str [] = EditLayout3Controller.str2; //editlayout3 data reserved

	//The new 2nd layout instance to open it.	
	public static Stage stage2 = new Stage();


	@FXML
	private void okButtoncontrol(ActionEvent event) throws Exception {

		if(x>=1){

			//get textfield data from here
			timedata[0]= time.getText().toString();
			timedata[1]=cCode.getText().toString();
			timedata[2]=roomNo.getText().toString();
			timedata[3]=nameOfTeacher.getText().toString();

			System.out.println(str[0]+" "+ str[1]+" "+str[2] +" " + str[3]);
			for(int i=0; i<4;i++){
				System.out.print(timedata[i]+" ");
			}


			sqmodelObj1.insertData(str[0], str[1], str[2], timedata[0], timedata[1],timedata[2], timedata[3], str[3]);


			if(timedata[0].isEmpty() || timedata[1].isEmpty() || timedata[2].isEmpty() || timedata[3].isEmpty()){
				obj2.getAlart("SORRY!!!\nYOU HAVE TO FILL ALL THE EMPTY FIELDS...", "Be Alert!!!");
			}else{
				stage2.close();
				if(x==1){
					openNewLayout("/application/Layout2.fxml + *** ROUTINE MANAGEMENT ***");
				}else{	
					openNewLayout("/application/ClassInfoLayout5.fxml + CLASS SCHEDUELS...");
					x--;			
				}
			}

		}
	}


	//With the beginning of the new layout the previous one will close here.
	public static void closeMain(Stage stage) {
		stage = (Stage) stage.getScene().getWindow();
		stage.close();
	}


	//The every 2nd layout will begin from here with a title from the argument.
	public  void openNewLayout(String str1)  {
		String st [] = str1.split("\\+");
		try {		
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(st[0]));
			Parent root1 = (Parent) fxmlLoader.load();

			stage2.setScene(new Scene(root1)); 
			//stage2.getIcons().add(new Image("gameIcon.PNG"));
			stage2.setResizable(false);
			stage2.setTitle(st[1]);
			stage2.show();
		} catch(Exception e) {
			e.printStackTrace();
		}

	}

	public String getN() {
		return n;
	}

	public void setN(String n) {
		this.n = n;
	}


}
