package application;

public enum DayNames {
	DAY_NAME, SUNDAY, MONDAY, TUESDAY, WEDNESDAY,
	  THURSDAY, FRIDAY, SATURDAY;
}
