package application;

import java.util.Date;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class MainLayout2Controller {
 
private static  ClassInfoLayout5Controller obj5 = new ClassInfoLayout5Controller();
	
	@FXML
	private Label timeAndData;

	@FXML
	private CheckBox edit;

	@FXML
	private CheckBox show;

	@FXML
	private Button doit;


	private static boolean flag ;

	//the instance of the 1st stage or layout to close it when the 2nd layout will start.
	private static Stage stage1 = MainLayout2.primaryStage;

	@FXML
	private void initialize(){
		Date date = new Date();
		String todayDate = date.toString();
		timeAndData.setText(todayDate);

	}

	//CheckBox Checking which one is checked in main layout.
	@FXML
	private void checkBoxControl(ActionEvent event) {

		if(edit.isSelected()){
			show.setDisable(true);			
		}else if(show.isSelected()){
			edit.setDisable(true);
		}
	}

	public void getAlart(String infoMessage, String titleBar)
	{
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle(titleBar);
		alert.setHeaderText(null);
		alert.setContentText(infoMessage);
		alert.showAndWait();
	}


	//Let's play button controlling and decide which 2nd layout will display now.
	@FXML
	private void dobuttoncontrol(ActionEvent event) throws Exception {     
		
		if(edit.isSelected()){
			closeMain(stage1);
			setFlag(false);
			//System.out.println(flag);			
			obj5.openNewLayout("/application/EditLayout3.fxml + EDITING THE ROUTINE...");				
		}else if(show.isSelected()){
			closeMain(stage1);
			setFlag(true);
			//	System.out.println(flag);
			obj5.openNewLayout("/application/ClassGetInfoLayout6.fxml + SHEDUELED CLASSES...");	
		}else{
			getAlart("You have to select any one option given to continue!","Be Alert!!!");
		}
	}

	//With the beginning of the new layout the previous one will close here.
	private static void closeMain(Stage stage) {
		stage = (Stage) stage.getScene().getWindow();
		stage.close();
	}



	public boolean getFlag() {
		return flag;
	}

	public void setFlag(boolean f) {
		this.flag = f;
	}
}
