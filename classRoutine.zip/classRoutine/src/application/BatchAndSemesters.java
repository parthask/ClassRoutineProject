package application;

public class BatchAndSemesters {
	
}
