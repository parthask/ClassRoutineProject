package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;

public class GetInfo6Controller  {

	private static String [] str = new String [5];   //info of this layout is stored in this str to pass it in the next layout

	public String[] getStr() {
		return str;
	}

	public void setStr(String[] str) {
		GetInfo6Controller.str = str;
	}

	@FXML
	private ComboBox<String> sbox2;

	@FXML
	private ComboBox<String> bbox2;

	@FXML
	private ComboBox<String> dbox2;

	@FXML
	private Button show;

	@FXML
	private void initialize(){
		sbox2.setValue("CHOICE SEMESTER");
		bbox2.setValue("CHOICE BATCH");
		dbox2.setValue("CHOICE DAY NAME");

		sbox2.setItems(ChoiceBoxData.semester);
		bbox2.setItems(ChoiceBoxData.batch);
		dbox2.setItems(ChoiceBoxData.dayNames);
	}

	@FXML
	private void showOnAction(ActionEvent event) throws Exception {
		ClassInfoLayout5Controller obj5 = new ClassInfoLayout5Controller();
		str[0]= sbox2.getValue();
		str[1]= bbox2.getValue();
		str[2]= dbox2.getValue();

		if(str[0] == "CHOICE SEMESTER" || str[1] == "CHOICE BATCH" || str[2] == "CHOICE DAY NAME"){
			MainLayout2Controller obj2 =new  MainLayout2Controller();
			obj2.getAlart("CHOICE ALL THREE OPTIONS TO CONTINUE...", "Be Alert!!!");
		}else{
			ClassInfoLayout5Controller.stage2.close();
			obj5.openNewLayout("/application/ShowLayout4.fxml + CLASS SCHEDUELS...");
		}
	}

}
