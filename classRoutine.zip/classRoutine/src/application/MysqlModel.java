package application;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

public class MysqlModel {

	public static Connection connection ;
	public static PreparedStatement prepstate  ;
	public static ResultSet result;
	
	private static String no;
	
	//private ArrayList <String> arr = new ArrayList<String>();
	private static ArrayList <String> arr2 = new ArrayList<String>();  // column name is here
	private static ArrayList <String> arr3 = new ArrayList<String>(); // result set is here


	public static  void SqliteModelConnection(){
		connection = SqliteConnection.connect();
		if(connection == null ){
			System.exit(0);
		}else{
			System.out.println("System is Connected...");
		}
	}

	public void insertData(String semester, String batch, String day, String time, String code,
			String room, String teacher, String noOfClass) {
		
		MysqlModel.SqliteModelConnection();
		
		
		String classInfo = time +", " + code +", " + room +", "+ teacher ;
		try{
			String query = "insert into routineinfo (semester, batch, dayname, noofclass, classinfo ) values (?, ?, ?, ?, ?);";
			
			prepstate  = connection.prepareStatement(query);
			
			if(connection == null){
				System.out.println("Connection problem...");
			}else if(prepstate == null){
				System.out.println("Statement problem...");
			}else if(result == null){
				System.out.println("resultset problem...");
			}

			prepstate.setString(1, semester);
			prepstate.setString(2, batch);
			prepstate.setString(3, day);
			prepstate.setString(4, noOfClass);
			prepstate.setString(5, classInfo);

			prepstate.executeUpdate();

			getQueiedData(semester, batch, day);

		} catch (Exception e) {
			e.printStackTrace ();
			System.out.println("ADD INSERT-> "+e);
		}

	}


	//sql for querying a column in a table
	/*
	SELECT * 
	FROM information_schema.COLUMNS 
	WHERE 
	    TABLE_SCHEMA = 'db_name' 
	AND TABLE_NAME = 'table_name' 
	AND COLUMN_NAME = 'column_name'

	SELECT * FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = 'my_table' AND COLUMN_NAME = 'my_column'

	 */



	//showing the routine on last layout
	public void getQueiedData(String day, String sem, String bat) throws SQLException{
		MysqlModel.SqliteModelConnection();

		String query = "select * from routineinfo Where semester = ? and batch = ? and dayname = ? ;";

		try {
			prepstate = connection.prepareStatement(query);
			
			if(connection == null){
				System.out.println("Connection problem...");
			}else if(prepstate == null){
				System.out.println("Statement problem...");
			}else if(result == null){
				System.out.println("resultset problem...");
			}

			prepstate.setString(1, sem);
			prepstate.setString(2, bat);
			prepstate.setString(3, day );

			result = prepstate.executeQuery();

			showResult();

		} catch (Exception e) {
			System.out.println("GETDATA 1-> "+e);
		}

	}
	
	
	public void getClassInfoFromDB(String sem, String bat, String day) throws SQLException{
		MysqlModel.SqliteModelConnection();

		String query = "select classinfo from routineinfo Where semester = ? and batch = ? and dayname = ? ;";

		try {
			prepstate = connection.prepareStatement(query);

			prepstate.setString(1, sem);
			prepstate.setString(2, bat);
			prepstate.setString(3, day );

			result = prepstate.executeQuery();
			
			if(connection == null){
				System.out.println("Connection problem...");
			}else if(prepstate == null){
				System.out.println("Statement problem...");
			}else if(result == null){
				System.out.println("resultset problem...");
			}
			

//			no = result.getString(1);
//		System.out.println("no of class: " + getNo());
		
			//result.close();
			//getQueiedData(sem, bat, day);
			arr3.clear();
			while(result.next()){
				arr3.add(result.getString("classinfo"));
			}

		} catch (Exception e) {
			System.out.println("At sql model GETDATA 2-> "+e);
		}
		
	}
	
	
	private void showResult() throws SQLException {
		MysqlModel.SqliteModelConnection();
		
		
		int i;
		
		// I don't take revenge, not even do forgive, I just Ignore!

		// Get the ResultSetMetaData.  This will be used for
		// the column headings

		ResultSetMetaData rsmd = result.getMetaData ();

		// Get the number of columns in the result set

		int numCols = rsmd.getColumnCount ();

		// Display column headings
		arr2.clear();
		arr3.clear();

		for (i=1; i<=numCols; i++) {
			if (i > 1){ System.out.print(", ");}
			arr2.add(rsmd.getColumnLabel(i));
			System.out.print(rsmd.getColumnLabel(i));
		}
		System.out.println("");

		// Display data, fetching until end of the result set

		boolean more = result.next ();
		
		while (more) {

			// Loop through each column, getting the
			// column data and displaying

			for (i=1; i<=numCols; i++) {
				if (i > 1) System.out.print(", ");
				arr3.add(result.getString(i));
				System.out.print(result.getString(i));
			}
			System.out.println("");

			// Fetch the next result set row

			more = result.next ();
		}
	}

	public ArrayList<String> getArr2() {
		return arr2;
	}

	public void setArr2(ArrayList<String> arr2) {
		MysqlModel.arr2 = arr2;
	}

	public ArrayList<String> getArr3() {
		return arr3;
	}

	public void setArr3(ArrayList<String> arr3) {
		MysqlModel.arr3 = arr3;
	}

	public String getNo() {
		return no;
	}

	public void setNo(String no) {
		MysqlModel.no = no;
	}
}
