package application;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;


public class MainLayout2 extends Application {

	public static AnchorPane root ;
	public static Stage primaryStage;
	//private static RoutineDB obj;


	//main Layout display.
	@Override
	public void start(Stage pStage) {
		try {
			MainLayout2.primaryStage = pStage;
			root = new AnchorPane();
			root= FXMLLoader.load(getClass().getResource("/application/Layout2.fxml"));
			Scene scene = new Scene(root);
			//scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			primaryStage.setScene(scene);
			//primaryStage.getIcons().add(new Image("gameIcon.PNG"));
			primaryStage.setTitle("*** ROUTINE MANAGEMENT ***");
			primaryStage.setResizable(false);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
			System.out.println("IN MAIN.");
		}
	}

	public static void main(String[] args) {

		//launch(args);
		//Connection conn = new RoutineDB().conn();
		Application.launch(MainLayout2.class, new String[0]);

	}
}
