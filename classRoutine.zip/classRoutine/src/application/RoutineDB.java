package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class RoutineDB {

	
	private static String url   ="jdbc:mysql://localhost/routinedb";
	private static Connection con = null;
	
	public Connection  conn(){
	try{
	con= DriverManager.getConnection (
			url, "root", "");
	}catch (SQLException ex) {

	System.out.println ("\n*** SQLException caught ***\n");

	while (ex != null) {
		System.out.println ("SQLState: " +
				ex.getSQLState ());
		System.out.println ("Message:  " + ex.getMessage ());
		System.out.println ("Vendor:   " +
				ex.getErrorCode ());
		ex = ex.getNextException ();
		System.out.println ("");
		}
	}
	catch (java.lang.Exception ex) {

		// Got some other type of exception.  Dump it.

		ex.printStackTrace ();
	}
	return con;
	}
}
